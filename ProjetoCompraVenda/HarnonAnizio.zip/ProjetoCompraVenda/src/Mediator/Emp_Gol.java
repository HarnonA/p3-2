package Mediator;

public class Emp_Gol extends Colleague {

	public Emp_Gol(Mediator newMediator) {
		super(newMediator, "Gol");

	}

}