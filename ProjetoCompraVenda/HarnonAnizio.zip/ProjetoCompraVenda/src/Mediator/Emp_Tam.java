package Mediator;

public class Emp_Tam extends Colleague {

	public Emp_Tam(Mediator newMediator) {
		super(newMediator, "Tam");

	}

}
