package Mediator;

public class Emp_Azul extends Colleague {

	public Emp_Azul(Mediator newMediator) {
		super(newMediator, "Azul");

	}

}