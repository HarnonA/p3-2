package Prototype;


public class CriarPrototipo {

	public Aviao criarPrototipo(PrototipoAviao a) {
		return a.prototipo();

	}
	

}
