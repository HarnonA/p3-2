package Prototype;



public interface PrototipoAviao extends Cloneable {
	
	public Aviao prototipo();

}
