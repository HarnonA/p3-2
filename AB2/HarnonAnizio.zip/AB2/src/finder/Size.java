package finder;

public enum Size {
	MEDIUM, SMALL, LARGE, NOT_APPLICABLE
}
