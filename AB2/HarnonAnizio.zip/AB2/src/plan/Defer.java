package plan;

public class Defer extends Acao{
	Actionable act;
	
	public Defer(){
		act = new Actionable();
	}
	public void execute(Plan plan){
		super.executa();
		act.defer();
		
	}

}
