package plan;

public class NoActionable extends Act{

	public NoActionable() {
	}
	
	public void incubate() {
		System.out.println("NoActionable Incubate");
	}
	
	public void trash() {
		System.out.println("NoActionable Trash");
	}

}
