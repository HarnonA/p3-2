package plan;

public enum Action {
	DEFER, NEXT, SCHEDULED, DELEGATE, DO, INCUBATE, TRASH
}
