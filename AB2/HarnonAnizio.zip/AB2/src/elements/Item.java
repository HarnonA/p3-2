package elements;

public interface Item {
	
	void print(String activity);

}
