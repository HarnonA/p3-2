package elements;

public class Body implements Item {

	@Override
	public void print(String activity) {
		System.out.println("Body:" + activity);
	}
}
