package elements;

public class Invocation implements Item {

	@Override
	public void print(String activity) {
		System.out.println("Invocation: "+activity);
	}
}
