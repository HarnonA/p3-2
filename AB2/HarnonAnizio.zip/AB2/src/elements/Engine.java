package elements;

public class Engine implements Item {

	@Override
	public void print(String activity) {
		System.out.println("Engine: "+activity);
	}
}
