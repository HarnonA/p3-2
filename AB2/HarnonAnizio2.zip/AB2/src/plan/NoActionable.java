package plan;

public class NoActionable{

	public NoActionable() {
	}
	
	public void incubate() {
		System.out.println("NoActionable Incubate");
	}
	
	public void trash() {
		System.out.println("NoActionable Trash");
	}

}
