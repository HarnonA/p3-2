package plan;

public interface Acao {
	public void executa();
	

}
