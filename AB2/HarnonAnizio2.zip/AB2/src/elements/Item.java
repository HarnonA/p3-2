package elements;

public interface Item {
	void accept(I_BuildPlan visitor);
}
