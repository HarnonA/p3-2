package elements;

public class PrintPlan implements I_BuildPlan {

	@Override
	public void visit(BuildPlan buildPlan) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(Body body) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(Engine engine) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(Invocation invocation) {
		// TODO Auto-generated method stub

	}

}
