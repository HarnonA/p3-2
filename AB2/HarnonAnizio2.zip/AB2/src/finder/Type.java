package finder;

public enum Type {
	file, database
}
