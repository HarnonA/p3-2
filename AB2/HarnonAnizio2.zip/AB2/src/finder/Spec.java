package finder;

public interface Spec {
	public boolean isSatisfied(Resource resource);

}
