package Mediator.ComMediator;

public interface Mediator {
	 
    void enviar(String mensagem, Colleague colleague);
 
}
