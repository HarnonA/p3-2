package Animal;

public interface Animais {
	
	public String toString();

}
