package Animal;

public class Main {
	
	public static void main(String[] args){
			
		Ovelha ovelha1 = new Ovelha( 4, "Ovelha1 " );
		System.out.println(ovelha1);
		Ovelha ovelha2 = new Ovelha(4, "Ovelha2 " );
		System.out.println(ovelha2);
		
		
	}

}