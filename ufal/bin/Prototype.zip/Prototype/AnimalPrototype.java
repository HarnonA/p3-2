package Prototype;

public interface AnimalPrototype extends Cloneable {
	
	public AnimalPrototype clonar();

}
