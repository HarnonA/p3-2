package Prototype;

public class CriarClones {
	
	public AnimalPrototype realizarClone(AnimalPrototype animalAClonar) {

		return animalAClonar.clonar();		
	}

}
